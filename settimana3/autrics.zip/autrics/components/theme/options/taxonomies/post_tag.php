<?php if (!defined('ABSPATH')) die('Direct access forbidden.');

$options = array(
    'autrics_post_term'=>array(
        'type'  => 'icon',
        'label' =>esc_html__(' icon', 'autrics'),
        'desc'  =>esc_html__('Term icon', 'autrics'),
    ),
);