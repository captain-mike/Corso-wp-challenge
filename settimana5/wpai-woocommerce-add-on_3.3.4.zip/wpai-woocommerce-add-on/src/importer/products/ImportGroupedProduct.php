<?php

namespace wpai_woocommerce_add_on\importer\products;

/**
 *
 * Import Grouped Product.
 *
 * Class ImportGroupedProduct
 * @package wpai_woocommerce_add_on\importer
 */
class ImportGroupedProduct extends ImportProduct {

    /**
     * @var string
     */
    protected $productType = 'grouped';

}
