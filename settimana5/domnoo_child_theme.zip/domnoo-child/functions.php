<?php

function domnoo_child_enqueue_styles() {
	wp_enqueue_style( 'domnoo-child-style', get_stylesheet_uri() );
}

add_action( 'wp_enqueue_scripts', 'domnoo_child_enqueue_styles', 100 );